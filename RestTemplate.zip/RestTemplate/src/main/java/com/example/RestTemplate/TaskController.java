package com.example.RestTemplate;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TaskController {
    private final ParallelTaskService taskService;

    public TaskController(ParallelTaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/run")
    public String runTasks() {
        taskService.executeThreeTasks(); // Arka planda başlat
        return "🎯 Görevler başlatıldı. Konsolu izle!";
    }
}
