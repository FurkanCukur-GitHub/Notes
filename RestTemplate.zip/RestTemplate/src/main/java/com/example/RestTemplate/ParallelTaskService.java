package com.example.RestTemplate;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.concurrent.CompletableFuture;

@Service
public class ParallelTaskService {
    @Async
    public void executeThreeTasks() {
        long globalStart = System.currentTimeMillis();
        log("🔄 Tüm görevler başlatılıyor...");

        // Paralel task'lar
        CompletableFuture<Void> task1 = CompletableFuture.runAsync(() -> runTask("1", 3000));
        CompletableFuture<Void> task2 = CompletableFuture.runAsync(() -> runTask("2", 4000));
        CompletableFuture<Void> task3 = CompletableFuture.runAsync(() -> runTask("3", 2000));

        // Hepsi bitsin
        CompletableFuture.allOf(task1, task2, task3).join();

        long globalEnd = System.currentTimeMillis();
        log("✅ Tüm görevler tamamlandı. Toplam süre: " + (globalEnd - globalStart) + " ms");
    }

    private void runTask(String id, int durationMs) {
        long start = System.currentTimeMillis();
        log("Task " + id + " 🟢 başladı (" + durationMs + " ms sürecek)");

        try {
            Thread.sleep(durationMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        long end = System.currentTimeMillis();
        log("Task " + id + " 🔴 bitti. Geçen süre: " + (end - start) + " ms");
    }

    private void log(String message) {
        System.out.println(LocalTime.now() + " [" + Thread.currentThread().getName() + "] " + message);
    }
}
