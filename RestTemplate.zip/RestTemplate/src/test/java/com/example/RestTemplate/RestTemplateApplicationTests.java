package com.example.RestTemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
